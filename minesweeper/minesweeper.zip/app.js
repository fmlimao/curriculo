function randomIntFromInterval(min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min);
}

var bombs = 10;
var width = 20;
var height = 10;
var table = [];
var started = false;
var openeds = [];

function createTable() {
    table = [];

    for (var y = 0; y < height; y++) {
        var row = [];

        for (var x = 0; x < width; x++) {
            row.push(null);
        }

        table.push(row);
    }
}

function shuffleBombs(yUser, xUser) {
    if (typeof yUser === 'undefined') yUser = null;
    if (typeof xUser === 'undefined') xUser = null;

    // console.log('yUser', typeof yUser, yUser);
    // console.log('xUser', typeof xUser, xUser);

    for (var b = 0; b < bombs; b++) {
        do {
            var x = randomIntFromInterval(0, width - 1);
            var y = randomIntFromInterval(0, height - 1);
        } while (
            table[y][x] !== null
            || (
                yUser !== null && xUser !== null
                && y == yUser && x == xUser
            )
        );

        table[y][x] = 'b';
    }

    // table[0][6] = 'b';
    // table[0][9] = 'b';
    // table[1][2] = 'b';
    // table[1][3] = 'b';
    // table[2][1] = 'b';
    // table[2][8] = 'b';
    // table[3][3] = 'b';
    // table[4][6] = 'b';
    // table[5][2] = 'b';
    // table[6][3] = 'b';

    generateValues();
}

function generateValues() {

    function verifyIfFieldsExists(y, x) {
        // console.log('verifyIfFieldExists()', y, x);
        /*

        y-1, x-1 | y-1, x | y-1, x+1
        y  , x-1 | y  , x | y  , x+1
        y+1, x-1 | y+1, x | y+1, x+1

        */

        // linha de cima
        if (typeof table[y - 1] !== 'undefined') {
            // existe linha de cima

            // coluna da esquerda
            if (typeof table[y - 1][x - 1] !== 'undefined') {
                // existe o da esquerda
                incrementValue(y - 1, x - 1);
            }

            // central
            incrementValue(y - 1, x);

            // coluna da direita
            if (typeof table[y - 1][x + 1] !== 'undefined') {
                // existe o da direita
                incrementValue(y - 1, x + 1);
            }
        }

        // linha central

        // coluna da esquerda
        if (typeof table[y][x - 1] !== 'undefined') {
            // existe o da esquerda
            incrementValue(y, x - 1);
        }

        // coluna da direita
        if (typeof table[y][x + 1] !== 'undefined') {
            // existe o da direita
            incrementValue(y, x + 1);
        }

        // linha de baixo
        if (typeof table[y + 1] !== 'undefined') {
            // existe linha de baixo

            // coluna da esquerda
            if (typeof table[y + 1][x - 1] !== 'undefined') {
                // existe o da esquerda
                incrementValue(y + 1, x - 1);
            }

            // central
            incrementValue(y + 1, x);

            // coluna da direita
            if (typeof table[y + 1][x + 1] !== 'undefined') {
                // existe o da direita
                incrementValue(y + 1, x + 1);
            }
        }

    }

    function incrementValue(y, x) {
        // console.log('incrementValue()', y, x);
        if (table[y][x] !== 'b') {
            if (table[y][x] === null) table[y][x] = 0;
            table[y][x]++;
        }
    }

    // procurando as bombas...
    for (var y = 0; y < height; y++) {

        for (var x = 0; x < width; x++) {

            // se encontrar a bomba...
            if (table[y][x] === 'b') {
                // da ++ em volta dela
                verifyIfFieldsExists(y, x);
            }
        }

    }

    console.log(table);

}

function selectCell(y, x) {
    if (!started) {
        shuffleBombs(y, x);
        started = true;
    }

    var key = `${y},${x}`;
    var canOpen = openeds.indexOf(key);
    console.log('canOpen', canOpen);

    if (canOpen === -1) {
        console.log('abrindo...', key);
        openeds.push(key);

        var value = table[y][x];
        console.log('value', value);

        if (value === 'b') {
            // fim do jogo
            console.log('FIM DO JOGO');
        } else if (!value) {
            // abre os em volta
            console.log('ABRINDO OS QUE ESTAO EM VOLTA');
        } else {
            // é numero, entao mostra
            console.log('NUMERO:', value);
            openCell(y, x, value);
        }
    }
}


createTable();

// frontend aqui embaixo

function displayTable() {
    var $table = $('#table');
    var $inner = $table.find('.inner-box');

    $table.css({
        'width': (width * 20) + 20,
        'height': (height * 20) + 20,
    });

    $inner.css({
        'width': (width * 20) + 4,
        'height': (height * 20) + 4,
    });

    $inner.empty();

    for (var y = 0; y < height; y++) {
        var $row = $('<div class="row" />');
        $row.css('width', width * 20);

        for (var x = 0; x < width; x++) {
            var $col = $('<div class="col" />');

            var $btn = $(`<button class="btn-action" data-y="${y}" data-x="${x}"></button>`);
            $col.html($btn);

            $row.append($col);
        }

        $inner.append($row);
    }

    $table.append($inner);

    createActions();
}

function openCell(y, x, value) {
    if (typeof value === 'undefined') value = null;

    $(`.btn-action[data-y="${y}"][data-x="${x}"]`).addClass('opened');

    if (value) {
        $(`.btn-action[data-y="${y}"][data-x="${x}"]`).html(value);
    }
}

function createActions() {

    $('.btn-action').off('click').on('click', function (e) {
        e.preventDefault();

        var $el = $(this);
        var y = $el.attr('data-y');
        var x = $el.attr('data-x');

        selectCell(y, x);
    });

}

displayTable();

console.log(table);
